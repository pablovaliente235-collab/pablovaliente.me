================================================================================
 PV MASTER GRADE  -  Free Edition (DCTL)  v1.0
 Grading in linear light for DaVinci Resolve Studio
================================================================================

 (c) 2026 Pablo Valiente Gonzalez - All Rights Reserved
 Website : pablovaliente.me
 Contact : contact@pablovaliente.me

 Free to use. Modification and sale are not permitted.



WHAT IT IS
PV Master Grade Free is the free edition of the PV Master Grade OFX plugin. It
uses the same colour math: linear light in DaVinci Wide Gamut, CAT16 white
balance and OKLab saturation/density. With every slider at its default value
the image does NOT change.

INSTALL
1. Open "Project Settings".
2. Go to "Color Management" and choose "Open LUT Folder".
3. Drag and drop the DCTL file ("PV Master Grade.dctle") into this directory.
4. Restart DaVinci Resolve to apply the changes.

HOW TO USE
1. Work in DaVinci Wide Gamut / Intermediate (for example with an input Color
   Space Transform node: your camera -> DaVinci Wide Gamut / Intermediate).
2. On the Color page create a node and apply the DCTL effect. Pick
   "PV Master Grade" in the list.
3. Adjust the sliders. Input and output are DaVinci Wide Gamut: the tool does
   NOT convert the image to display.
4. Put the output transform last (for example PV DRT).

   Recommended chain:  input Color Space Transform -> PV Master Grade
                       -> PV DRT (last node)

Input Space: "DWG DaVinci Intermediate" (default) if your timeline is in
DaVinci Intermediate; "DWG Linear" if it is linear.

CONTROLS
 Base Grade
  Exposure Stops      Exposure in stops, on linear light.
  Flare               Positive lifts the blacks like veiling light in the lens;
                      negative sinks them.
  Color Temp K, Tint  Kelvin white balance (6500 = no change) and green/magenta
                      tint. Luminance is preserved.
  Contrast            Contrast that keeps RGB ratios, with a soft fall-off in
                      blacks and whites.
  Pivot Stops         Contrast pivot, in stops above 18% grey.
  Shadows             Gain on the shadows only.
  Highlights          Gain on the highlights only.
  Highlight Rolloff   Where Highlights starts to act: 0 = earlier, 1 = only on
                      the brightest areas (default 0.5).
 Saturation
  Saturation          A saturation that separates colours from each other,
                      cleaner than a conventional one. Negative desaturates.
  Filmic Saturation   More colour and, at the same time, more density in the
                      most saturated tones, as in film.
  Density             Darkens colours in proportion to how saturated they are;
                      neutrals are untouched.
 Color (Red, Green, Blue)
  Red/Green/Blue Hue      Rotate the hue of each colour (skin is protected).
  Red/Green/Blue Density  Darken (+) or lighten (-) that colour.
 Look
  Split Tone Amount   Tint strength (0 = off).
  Split Shadow Temp   Shadow temperature (-1 cool blue, +1 amber).
  Split Highlight Temp  Highlight temperature.
  Split Balance       Where shadows and highlights cross over.
                      Skin tones are NOT tinted, and deep blacks and whites stay
                      clean.
  Bleach Bypass       More contrast and less colour, like a skipped bleach.
 Finishing
  Sharpen OLPF        Positive: enhances detail on luminance, with no colour
                      halos. Negative: softens like an optical low-pass filter.
                      Scales with the project resolution.

ONLY IN THE OFX PLUGIN (full version)
Film emulation LUTs, precision 6-vector Hue Grade (yellow, cyan and magenta
included), saturation by range, Red Damping, Cool Boost, Density Focus,
3-zone Split Tone, halation, grain, gamma, toe, filmic shoulder and destination
illuminant.

REQUIREMENTS
DaVinci Resolve Studio (DCTLs do not run in the free version of Resolve).
Developed and tested on DaVinci Resolve Studio 21 on macOS.


================================================================================
 (c) 2026 Pablo Valiente Gonzalez - pablovaliente.me - contact@pablovaliente.me
 All Rights Reserved.
================================================================================
