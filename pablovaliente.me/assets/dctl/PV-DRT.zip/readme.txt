================================================================================
 PV DRT  -  Display Rendering Transform (DCTL)  v1.5
 Display rendering transform (SDR) for DaVinci Resolve Studio
================================================================================

 (c) 2026 Pablo Valiente Gonzalez - All Rights Reserved
 Website : pablovaliente.me
 Contact : contact@pablovaliente.me

 Free to use. Modification and sale are not permitted.



WHAT IT IS
PV DRT converts the image from DaVinci Wide Gamut to what you see on the
display. It goes in the LAST node, after grading, and replaces any other DRT or
output LUT (OpenDRT, Referent, JP-2499, etc.): do not stack them.

It has its own tone curve: mid grey at 10 nits over a 100-nit peak, exact
black and a long shoulder to white with no hard clipping. Greys stay neutral.
Soft tones (skin) are barely touched and do not change hue with exposure; very
saturated colours are compressed progressively so they do not break. In the
highlights colour fades to white continuously (overexposed skies, sunset
clouds) and incandescent lights keep their warmth.

INSTALL
1. Open "Project Settings".
2. Go to "Color Management" and choose "Open LUT Folder".
3. Drag and drop the DCTL file ("00 PV DRT.dctle") into this directory.
4. Restart DaVinci Resolve to apply the changes.

HOW TO USE
1. Bring the footage to DaVinci Wide Gamut / Intermediate with an input Color
   Space Transform node (your camera -> DaVinci Wide Gamut / Intermediate).
2. Grade in that space (for example with PV Master Grade).
3. On the LAST node apply the DCTL effect and pick "00 PV DRT".
4. Choose the output: Output Gamut (Rec709, P3 D65 or Rec2020) and Output EOTF
   (BT.1886 2.4, sRGB, Gamma 2.2 or Gamma 2.6). For a normal Rec.709 project:
   Rec709 + BT.1886 2.4 (the defaults).

   Recommended chain:  input Color Space Transform -> grade (PV Master Grade)
                       -> PV DRT (last node)

Important: the project must not apply another output transform on top (turn
automatic Color Management off or use a DaVinci YRGB timeline). SDR only: it
does not produce HDR (PQ / HLG).

CONTROLS (defaults already give the PV look)
 Output
  Input Space           DWG DaVinci Intermediate (default) or DWG Linear.
  Output Gamut          Rec709 / P3 D65 / Rec2020.
  Output EOTF           BT.1886 2.4 / sRGB / Gamma 2.2 / Gamma 2.6.
  Display Peak Nits     Display peak (100 by default).
  Display Grey Nits     Mid-grey level (10 by default).
 Tone
  Contrast              Global contrast of the curve (1.0).
  Shadow Toe            Shadow toe: higher = deeper blacks.
  Saturation Compression  How much very saturated colours are compressed.
  Highlight Desaturation  How much colour fades to white in the highlights.
  Hue Skew              Automatic hue rotation with exposure (0 = none).
  Density               Global density of saturated colours.
 Color
  Red Density           Density of saturated reds (lightness only).
  Blue Peak Saturation / Blue Peak Density
                        Saturation and density of the most saturated blues.
  Cool Saturation / Cool Shadow Chroma / Cool Density
                        Treatment of cool colours (cyan, blue, violet).
  Hue Red / Yellow / Green / Cyan / Blue / Magenta (degrees)
                        Manual hue rotation per colour (skin is excluded).
  Purity Red / Yellow / Green / Cyan / Blue / Magenta
                        Purity (saturation) per colour.

TIPS
- Start with everything at default and adjust only Contrast or Shadow Toe for
  more or less contrast.
- If a saturated colour looks too dense, lower Density or Red Density.
- For more colour in the highlights, lower Highlight Desaturation.

REQUIREMENTS
DaVinci Resolve Studio. Developed and tested on DaVinci Resolve Studio 21 on
macOS.


================================================================================
 (c) 2026 Pablo Valiente Gonzalez - pablovaliente.me - contact@pablovaliente.me
 All Rights Reserved.
================================================================================
